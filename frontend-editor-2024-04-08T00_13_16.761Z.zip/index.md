// variáveis
const mensagem = 'Oi'
// tipos de dados
  // number
  // string
// função
alert(mensagem)